Bored while reading an article? use the chrome extension to test your typing speed while reading the article 

**How to Run the program**
Download the zip file
Chrome Extension  > Load Unpacked files > select folder 
Go to an article > Click on the extension > test your writing speed!